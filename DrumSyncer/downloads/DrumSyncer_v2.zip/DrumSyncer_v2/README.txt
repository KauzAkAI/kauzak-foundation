================================================================
  DRUMSYNCER v2.0 — Kauzak Foundation
  드럼싱커 v2.0 — 카우작 재단
================================================================

  AI-powered drum cover video production tool.
  AI 기반 드럼 커버 영상 제작 도구.

================================================================
  QUICK START / 빠른 시작
================================================================

  FIRST TIME:
  처음 사용 시:

    1. Double-click "install.bat" (Run as Administrator)
       "install.bat"을 더블클릭하세요 (관리자 권한으로 실행)

    2. Wait for all software to install (5-10 minutes)
       모든 소프트웨어가 설치될 때까지 기다리세요 (5-10분)

  EVERY TIME:
  매번 사용할 때:

    1. Double-click "start.bat"
       "start.bat"을 더블클릭하세요

    2. Browser opens to http://localhost:5151
       브라우저가 http://localhost:5151 에서 열립니다

================================================================
  HOW TO USE / 사용 방법
================================================================

  TEST MODE / 테스트 모드:
  ─────────────────────────
  Takes a drum cover video, separates the drums from the
  backing track, then reassembles to verify sync quality.

  드럼 커버 영상에서 드럼과 배킹 트랙을 분리한 후
  다시 합쳐서 싱크 품질을 확인합니다.

    → Upload a drum cover video OR paste a YouTube URL
      드럼 커버 영상을 업로드하거나 YouTube URL을 붙여넣으세요

    → Click START / 시작을 클릭하세요

    → Download the output video, drums-only, and backing
      출력 영상, 드럼만, 배킹을 다운로드하세요


  PRODUCTION MODE / 프로덕션 모드:
  ─────────────────────────────────
  Takes an original song, a drum recording, and a video.
  Syncs them all together into a finished product.

  원본 곡, 드럼 녹음, 영상을 가져와서
  모두 합쳐 완성된 결과물을 만듭니다.

    → Upload three files:
      세 개의 파일을 업로드하세요:
        1. Original Song (MP3/WAV) / 원본 곡
        2. Drum Recording (WAV) / 드럼 녹음
        3. Video File (MP4) / 영상 파일

    → Click START / 시작을 클릭하세요


  YOUTUBE URL / YouTube URL 입력:
  ───────────────────────────────
  Instead of uploading a file, you can paste a YouTube
  URL and DrumSyncer will download it automatically.

  파일을 업로드하는 대신 YouTube URL을 붙여넣으면
  DrumSyncer가 자동으로 다운로드합니다.


================================================================
  WHAT IT DOES / 작동 원리
================================================================

  1. EXTRACT — Pulls audio from your video
     추출 — 영상에서 오디오를 추출합니다

  2. SEPARATE — AI (Demucs) splits drums from music
     분리 — AI(Demucs)가 드럼과 음악을 분리합니다

  3. ANALYZE — Detects beats in both tracks
     분석 — 두 트랙에서 비트를 감지합니다

  4. SYNC — Cross-correlates beats for perfect alignment
     싱크 — 비트를 상호 상관시켜 완벽하게 맞춥니다

  5. MIX — Blends tracks to your specifications
     믹스 — 사양에 맞게 트랙을 혼합합니다

  6. EXPORT — Combines audio with video
     내보내기 — 오디오를 영상과 결합합니다

================================================================
  SYSTEM REQUIREMENTS / 시스템 요구 사항
================================================================

  - Windows 10/11 (64-bit)
  - 8 GB RAM minimum (16 GB recommended)
    최소 8 GB RAM (16 GB 권장)
  - 2 GB free disk space for software
    소프트웨어용 2 GB 여유 디스크 공간
  - Internet connection for YouTube downloads
    YouTube 다운로드를 위한 인터넷 연결

  The installer will download and set up:
  설치 프로그램이 다운로드하고 설정합니다:
  - Python 3.10
  - FFmpeg
  - yt-dlp
  - PyTorch (CPU version)
  - Demucs, librosa, Flask, and other libraries

================================================================
  FILES IN THIS PACKAGE / 이 패키지의 파일
================================================================

  install.bat ......... Auto-installer (run first)
                        자동 설치 프로그램 (먼저 실행)

  start.bat ........... Launch DrumSyncer
                        DrumSyncer 실행

  drumsyncer_app.py ... Web interface + processing server
                        웹 인터페이스 + 처리 서버

  drum_syncer.py ...... CLI tool (command line version)
                        CLI 도구 (명령줄 버전)

  README.txt .......... This file / 이 파일

================================================================
  TROUBLESHOOTING / 문제 해결
================================================================

  "Python not found"
  → Run install.bat again, or install Python from python.org
    install.bat를 다시 실행하거나 python.org에서 Python을 설치하세요

  "FFmpeg not found"
  → Download from ffmpeg.org, put ffmpeg.exe in the bin\ folder
    ffmpeg.org에서 다운로드하여 bin\ 폴더에 넣으세요

  "Port 5151 already in use"
  → Close any other DrumSyncer instance, or change port in app
    다른 DrumSyncer 인스턴스를 닫거나 앱에서 포트를 변경하세요

  Processing is slow
  → Demucs runs on CPU by default. 90 seconds of audio takes
    about 3 minutes. GPU support available with NVIDIA CUDA.
    Demucs는 기본적으로 CPU에서 실행됩니다. 90초 오디오는
    약 3분이 걸립니다. NVIDIA CUDA로 GPU 지원이 가능합니다.

================================================================
  Kauzak Foundation — kauzak.foundation
  Copyright 2026 Kauzak Foundation. All rights reserved.
================================================================
