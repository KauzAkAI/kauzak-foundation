@echo off
setlocal enabledelayedexpansion
title DrumSyncer v2.0 — Installer / 드럼싱커 v2.0 — 설치
color 0f

echo.
echo  ===================================================
echo   DrumSyncer v2.0 — Auto Installer
echo   드럼싱커 v2.0 — 자동 설치 프로그램
echo   Kauzak Foundation / 카우작 재단
echo  ===================================================
echo.
echo  This will install all required software:
echo  필요한 모든 소프트웨어를 설치합니다:
echo.
echo    1. Python 3.10+
echo    2. FFmpeg (audio/video processing)
echo    3. yt-dlp (YouTube downloader)
echo    4. AI Libraries (Demucs, PyTorch, librosa)
echo.
echo  ===================================================
echo.
pause

:: ── Check for Admin ──
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [!] Administrator privileges recommended.
    echo  [!] 관리자 권한이 권장됩니다.
    echo.
    echo  Right-click install.bat and select "Run as administrator"
    echo  install.bat를 우클릭하고 "관리자 권한으로 실행"을 선택하세요
    echo.
    pause
)

:: ── Set install directory ──
set "INSTALL_DIR=%~dp0"
set "BIN_DIR=%INSTALL_DIR%bin"
set "VENV_DIR=%INSTALL_DIR%venv"
mkdir "%BIN_DIR%" 2>nul

echo.
echo  [Step 1/5] Checking Python...
echo  [1/5단계] Python 확인 중...

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYVER=%%i
    echo  [OK] Python !PYVER! found.
    set "PYTHON=python"
    goto :check_pip
)

python3 --version >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=2" %%i in ('python3 --version 2^>^&1') do set PYVER=%%i
    echo  [OK] Python !PYVER! found.
    set "PYTHON=python3"
    goto :check_pip
)

echo  [!] Python not found. Downloading Python 3.10...
echo  [!] Python을 찾을 수 없습니다. Python 3.10을 다운로드합니다...
echo.

:: Download Python installer
set "PY_URL=https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe"
set "PY_INSTALLER=%TEMP%\python_installer.exe"

powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_INSTALLER%'}"

if not exist "%PY_INSTALLER%" (
    echo  [ERROR] Failed to download Python.
    echo  [오류] Python 다운로드에 실패했습니다.
    echo  Please install Python 3.10+ manually from https://python.org
    pause
    exit /b 1
)

echo  Installing Python (this may take a minute)...
echo  Python 설치 중 (1분 정도 걸릴 수 있습니다)...
"%PY_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1

:: Refresh PATH
set "PATH=%LOCALAPPDATA%\Programs\Python\Python310;%LOCALAPPDATA%\Programs\Python\Python310\Scripts;%PATH%"
set "PYTHON=python"

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python installation failed.
    echo  [오류] Python 설치에 실패했습니다.
    pause
    exit /b 1
)
echo  [OK] Python installed successfully.
echo  [OK] Python이 성공적으로 설치되었습니다.

:check_pip
echo.
echo  [Step 2/5] Checking FFmpeg...
echo  [2/5단계] FFmpeg 확인 중...

ffmpeg -version >nul 2>&1
if %errorlevel% equ 0 (
    echo  [OK] FFmpeg found in PATH.
    goto :check_ytdlp
)

echo  Downloading FFmpeg...
echo  FFmpeg 다운로드 중...

set "FF_URL=https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"
set "FF_ZIP=%TEMP%\ffmpeg.zip"

powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%FF_URL%' -OutFile '%FF_ZIP%'}"

if not exist "%FF_ZIP%" (
    echo  [WARNING] Could not download FFmpeg automatically.
    echo  [경고] FFmpeg를 자동으로 다운로드할 수 없습니다.
    echo  Please download FFmpeg from https://ffmpeg.org and place ffmpeg.exe in:
    echo  %BIN_DIR%
    goto :check_ytdlp
)

echo  Extracting FFmpeg...
echo  FFmpeg 압축 해제 중...
powershell -Command "Expand-Archive -Path '%FF_ZIP%' -DestinationPath '%TEMP%\ffmpeg_extract' -Force"

:: Find and copy ffmpeg.exe
for /r "%TEMP%\ffmpeg_extract" %%f in (ffmpeg.exe) do (
    copy "%%f" "%BIN_DIR%\ffmpeg.exe" >nul
    echo  [OK] FFmpeg installed to bin\ffmpeg.exe
    goto :found_ffmpeg
)
echo  [WARNING] ffmpeg.exe not found in download.

:found_ffmpeg
:: Also grab ffprobe
for /r "%TEMP%\ffmpeg_extract" %%f in (ffprobe.exe) do (
    copy "%%f" "%BIN_DIR%\ffprobe.exe" >nul
)
rd /s /q "%TEMP%\ffmpeg_extract" 2>nul

:check_ytdlp
echo.
echo  [Step 3/5] Checking yt-dlp...
echo  [3/5단계] yt-dlp 확인 중...

yt-dlp --version >nul 2>&1
if %errorlevel% equ 0 (
    echo  [OK] yt-dlp found in PATH.
    goto :install_python_deps
)

echo  Downloading yt-dlp...
echo  yt-dlp 다운로드 중...

set "YT_URL=https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%YT_URL%' -OutFile '%BIN_DIR%\yt-dlp.exe'}"

if exist "%BIN_DIR%\yt-dlp.exe" (
    echo  [OK] yt-dlp installed to bin\yt-dlp.exe
) else (
    echo  [WARNING] Could not download yt-dlp. YouTube URL feature will not work.
    echo  [경고] yt-dlp를 다운로드할 수 없습니다. YouTube URL 기능이 작동하지 않습니다.
)

:install_python_deps
echo.
echo  [Step 4/5] Installing Python packages...
echo  [4/5단계] Python 패키지 설치 중...
echo.
echo  This may take 5-10 minutes on first install.
echo  첫 설치 시 5-10분이 걸릴 수 있습니다.
echo.

:: Add bin to PATH for this session
set "PATH=%BIN_DIR%;%PATH%"

:: Install CPU-only PyTorch first (smaller download)
echo  Installing PyTorch (CPU)...
echo  PyTorch (CPU) 설치 중...
%PYTHON% -m pip install torch torchaudio --index-url https://download.pytorch.org/whl/cpu --quiet

:: Install remaining dependencies
echo  Installing audio processing libraries...
echo  오디오 처리 라이브러리 설치 중...
%PYTHON% -m pip install flask demucs librosa soundfile scipy numpy --quiet

:: Install yt-dlp Python package as backup
%PYTHON% -m pip install yt-dlp --quiet

echo.
echo  [OK] All Python packages installed.
echo  [OK] 모든 Python 패키지가 설치되었습니다.

:: ── Verify Installation ──
echo.
echo  [Step 5/5] Verifying installation...
echo  [5/5단계] 설치 확인 중...
echo.

set ERRORS=0

%PYTHON% -c "import flask" >nul 2>&1
if %errorlevel% equ 0 (echo  [OK] Flask) else (echo  [FAIL] Flask & set /a ERRORS+=1)

%PYTHON% -c "import demucs" >nul 2>&1
if %errorlevel% equ 0 (echo  [OK] Demucs) else (echo  [FAIL] Demucs & set /a ERRORS+=1)

%PYTHON% -c "import librosa" >nul 2>&1
if %errorlevel% equ 0 (echo  [OK] librosa) else (echo  [FAIL] librosa & set /a ERRORS+=1)

%PYTHON% -c "import torch" >nul 2>&1
if %errorlevel% equ 0 (echo  [OK] PyTorch) else (echo  [FAIL] PyTorch & set /a ERRORS+=1)

%PYTHON% -c "import soundfile" >nul 2>&1
if %errorlevel% equ 0 (echo  [OK] SoundFile) else (echo  [FAIL] SoundFile & set /a ERRORS+=1)

echo.

if %ERRORS% gtr 0 (
    echo  [WARNING] %ERRORS% package(s) failed to install.
    echo  [경고] %ERRORS%개의 패키지 설치에 실패했습니다.
    echo  Try running this installer again or install manually.
) else (
    echo  ===================================================
    echo   Installation Complete! / 설치 완료!
    echo  ===================================================
    echo.
    echo   To launch DrumSyncer, double-click:
    echo   DrumSyncer를 실행하려면 더블클릭하세요:
    echo.
    echo     start.bat
    echo.
    echo   Or run: %PYTHON% drumsyncer_app.py
    echo.
    echo  ===================================================
)

echo.
pause
