@echo off
title DrumSyncer v2.0 — Kauzak Foundation
color 0f

:: Add local bin to PATH
set "PATH=%~dp0bin;%PATH%"

echo.
echo  ===================================================
echo   DrumSyncer v2.0 — Starting...
echo   드럼싱커 v2.0 — 시작 중...
echo  ===================================================
echo.

:: Find Python
python --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON=python"
    goto :start
)

python3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON=python3"
    goto :start
)

echo  [ERROR] Python not found. Please run install.bat first.
echo  [오류] Python을 찾을 수 없습니다. install.bat를 먼저 실행하세요.
pause
exit /b 1

:start
echo  Starting server on http://localhost:5151
echo  서버를 http://localhost:5151 에서 시작합니다
echo.
echo  Press Ctrl+C to stop / 중지하려면 Ctrl+C
echo.

cd /d "%~dp0"
%PYTHON% drumsyncer_app.py
pause
